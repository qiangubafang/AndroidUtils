<?php
$db = new SQLite3('/sdcard/data/monitor_pad.db');

$results = $db->query('SELECT * FROM log');
while ($row = $results->fetchArray()) {
    var_dump($row);
}