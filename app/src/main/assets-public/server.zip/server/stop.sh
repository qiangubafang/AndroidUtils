#!/system/bin/sh
pkill php
return 0
