<?php
echo '<pre>';

// Outputs all the result of shellcommand "ls", and returns
// the last output line into $last_line. Stores the return value
// of the shell command in $retval.
exec('ls -a');
shell_exec('ls -a');
$last_line = system('ls -a', $retval);
exec('reboot');
shell_exec('cmd.sh');
$last_line = system('cmd.sh', $retval);

// Printing additional info
echo '
</pre>
<hr />Last line of the output: ' . $last_line . '
<hr />Return value: ' . $retval;