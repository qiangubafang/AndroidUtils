#!/system/bin/sh

export path=$1
export server_dir="/sdcard/www"
cd $path
if $busybox test ! -d $server_dir ; then
  busybox mkdir -p $server_dir
  busybox cp $path/www/* $server_dir
fi
if $busybox test ! -e $server_dir/php.ini ; then
  busybox cp $path/www/php.ini $server_dir
fi
if $busybox test ! -e $server_dir/resolv.conf ; then
  busybox cp $path/www/resolv.conf $server_dir
fi


./php -S 0.0.0.0:80 -c $server_dir/php.ini -t $server_dir >/dev/null 2>&1 &


return 0
